import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ChatsListScreen from './ChatsListScreen';
import ChatScreen from './ChatScreen';

const Stack = createStackNavigator();
const STORAGE_KEY = 'chats_store';

export default function App() {
  const [chats, setChats] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored) setChats(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to load chats', e);
      }
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(chats)).catch(console.error);
  }, [chats]);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ChatsList">
        <Stack.Screen name="ChatsList" options={{ title: 'Your Chats' }}>
          {props => <ChatsListScreen {...props} chats={chats} setChats={setChats} />}
        </Stack.Screen>
        <Stack.Screen name="Chat" options={{ title: 'MindMirror' }}>
          {props => <ChatScreen {...props} chats={chats} setChats={setChats} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
