import React, { useState, useEffect, useCallback } from 'react';
import { View, Button, StyleSheet } from 'react-native';
import { GiftedChat, Bubble } from 'react-native-gifted-chat';
import * as Speech from 'expo-speech';
import useVoice from './useVoice';
import { askOpenAI } from './openaiClient';

export default function ChatScreen({ navigation, route, chats, setChats }) {
  const initial = route.params?.messages || [];
  const initialTitle = route.params?.title || 'MindMirror Chat';
  const [messages, setMessages] = useState(initial);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const { isListening, result, startListening, stopListening } = useVoice();

  useEffect(() => {
    navigation.setOptions({ title: route.params?.title || initialTitle });
  }, [navigation, route.params]);

  const persistChat = (msgs) => {
    if (!msgs || msgs.length === 0) return;
    const firstMsg = msgs.find(m => m.user._id === 1) || msgs[msgs.length-1];
    const title = firstMsg && firstMsg.text ? (firstMsg.text.length > 30 ? firstMsg.text.slice(0,30) + '...' : firstMsg.text) : 'Untitled Chat';
    // replace existing if opened from list
    setChats(prev => {
      // if route provided messages and matched existing, avoid duplicate — simple approach: always append (user can clear)
      return [...prev.filter(p => p.messages !== msgs), { title, messages: msgs }];
    });
  };

  useEffect(() => {
    // persist when leaving screen
    const unsubscribe = navigation.addListener('beforeRemove', () => {
      persistChat(messages);
    });
    return unsubscribe;
  }, [navigation, messages]);

  const onSend = useCallback(async (newMessages = []) => {
    setMessages(prev => GiftedChat.append(prev, newMessages));

    const question = newMessages[0].text;
    setIsTyping(true);
    const reply = await askOpenAI(question);
    setIsTyping(false);

    const aiMessage = {
      _id: Math.random().toString(36),
      text: reply,
      createdAt: new Date(),
      user: { _id: 2, name: 'MindMirror AI' },
    };
    setMessages(prev => GiftedChat.append(prev, [aiMessage]));

    Speech.speak(reply, {
      language: 'en-US',
      onStart: () => setIsSpeaking(true),
      onDone: () => setIsSpeaking(false),
      onStopped: () => setIsSpeaking(false),
    });
  }, [setMessages]);

  const handleStopSpeaking = () => {
    Speech.stop();
    setIsSpeaking(false);
  };

  const handleNewChat = () => {
    persistChat(messages);
    setMessages([]);
  };

  const handleSendVoice = () => {
    if (result) {
      onSend([{ _id: Date.now().toString(), text: result, createdAt: new Date(), user: { _id: 1, name: 'You' } }]);
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <GiftedChat
        messages={messages}
        onSend={(msgs) => onSend(msgs)}
        user={{ _id: 1, name: 'You', avatar: 'https://i.pravatar.cc/100?img=12' }}
        isTyping={isTyping}
        renderBubble={(props) => (
          <Bubble
            {...props}
            wrapperStyle={{
              right: { backgroundColor: '#0066FF', borderRadius: 16 },
              left: { backgroundColor: '#ECECEC', borderRadius: 16 }
            }}
            textStyle={{ right: { color: '#fff' }, left: { color: '#111' } }}
          />
        )}
      />

      <View style={styles.controls}>
        <Button title={isListening ? 'Stop Listening 🎙️' : 'Start Voice 🎤'} onPress={isListening ? stopListening : startListening} />
        <Button title='Send Voice Result' onPress={handleSendVoice} />
        {isSpeaking && <Button title='Stop Speaking 🔇' onPress={handleStopSpeaking} />}
      </View>

      <View style={styles.footerBtns}>
        <Button title='New Chat ✨' onPress={handleNewChat} />
        <Button title='Back to Chats 📂' onPress={() => navigation.navigate('ChatsList')} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  controls: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 10, paddingHorizontal: 6 },
  footerBtns: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 }
});
