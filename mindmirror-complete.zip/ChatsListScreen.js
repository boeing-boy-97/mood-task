import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Modal, TextInput, Button } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = 'chats_store';

export default function ChatsListScreen({ navigation, chats, setChats }) {
  const [localChats, setLocalChats] = useState(chats || []);
  const [renameModalVisible, setRenameModalVisible] = useState(false);
  const [renameIndex, setRenameIndex] = useState(null);
  const [renameText, setRenameText] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setLocalChats(parsed);
          setChats(parsed);
        }
      } catch (e) {
        console.error('Load chats failed', e);
      }
    };
    const unsub = navigation.addListener('focus', load);
    load();
    return unsub;
  }, [navigation]);

  useEffect(() => {
    setLocalChats(chats);
  }, [chats]);

  const openChat = (chat) => {
    navigation.navigate('Chat', { messages: chat.messages, title: chat.title });
  };

  const requestRename = (index) => {
    setRenameIndex(index);
    setRenameText(localChats[index]?.title || '');
    setRenameModalVisible(true);
  };

  const confirmRename = async () => {
    if (renameIndex === null) return;
    const updated = [...localChats];
    updated[renameIndex].title = renameText.trim() || 'Untitled Chat';
    setLocalChats(updated);
    setChats(updated);
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setRenameModalVisible(false);
    setRenameIndex(null);
    setRenameText('');
  };

  const clearAll = async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    setLocalChats([]);
    setChats([]);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={localChats}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item, index }) => (
          <TouchableOpacity style={styles.chatItem} onPress={() => openChat(item)} onLongPress={() => requestRename(index)}>
            <Text style={styles.chatTitle}>{item.title}</Text>
            <Text style={styles.preview}>{item.messages?.[0]?.text?.slice(0,40) || 'Empty chat...'}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={{ color: 'gray', padding: 20 }}>No saved chats yet — start a new chat!</Text>}
      />

      <View style={{ padding: 12 }}>
        <TouchableOpacity style={styles.clearBtn} onPress={clearAll}>
          <Text style={{ color: 'white', textAlign: 'center' }}>Clear All 🗑️</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={renameModalVisible} transparent animationType='slide'>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalBox}>
            <Text style={{ fontWeight: 'bold', marginBottom: 8 }}>Rename chat</Text>
            <TextInput value={renameText} onChangeText={setRenameText} style={styles.input} />
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 }}>
              <Button title='Cancel' onPress={() => setRenameModalVisible(false)} />
              <Button title='Save' onPress={confirmRename} />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 8 },
  chatItem: { padding: 15, borderBottomWidth: 1, borderBottomColor: '#ddd' },
  chatTitle: { fontWeight: 'bold', fontSize: 16 },
  preview: { color: 'gray', marginTop: 6 },
  clearBtn: { backgroundColor: '#e74c3c', padding: 12, borderRadius: 6 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '85%', backgroundColor: 'white', padding: 16, borderRadius: 8 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 8, borderRadius: 6 }
});
