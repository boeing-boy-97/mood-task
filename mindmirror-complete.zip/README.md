# MindMirror — Full Stack Voice AI Chat (Expo + Express)

This archive includes a polished Expo app and a tiny Express server proxy to securely call OpenAI.

## What’s included
- **Client (Expo)**: GiftedChat UI, voice input, TTS, persistent multi-chat history, rename chats, new chat, clear all.
- **Server (Express)**: simple `/api/chat` endpoint that forwards prompts to OpenAI using the official SDK. Keeps your OpenAI API key off the client.

## Quick start (development)

1. Unzip and open the folder:
   ```bash
   cd mindmirror-complete
   ```

2. Install dependencies for the client and server (root contains client deps; server has its own):
   ```bash
   npm install
   cd server && npm install
   cd ..
   ```

3. Set environment variables:
   - On macOS / Linux:
     ```bash
     export OPENAI_API_KEY="sk-..."
     export SERVER_URL="http://localhost:3000"
     ```
   - On Windows (PowerShell):
     ```powershell
     $env:OPENAI_API_KEY="sk-..."
     $env:SERVER_URL="http://localhost:3000"
     ```

4. Start the Express server (in a terminal):
   ```bash
   npm run server
   ```
   The server listens on port 3000 by default and provides `/api/chat`.

5. Start the Expo app (in another terminal):
   ```bash
   npx expo start
   ```
   - Use Expo Go to scan the QR or press `a` / `i` to open emulator/simulator.

## Build for production
Because the app uses native modules (`@react-native-voice/voice`), use **EAS Build** to produce signed APK/IPA.
Follow Expo docs: https://docs.expo.dev/eas/

## Notes
- Do not commit your OpenAI key. Keep it in environment variables.
- If you run into `react-native-reanimated` errors, follow library install notes (babel plugin).
- The server uses the `openai` npm package. If SDK function names change, follow OpenAI SDK docs.

Enjoy! 🚀
