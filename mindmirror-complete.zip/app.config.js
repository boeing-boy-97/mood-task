import 'dotenv/config';

export default {
  expo: {
    name: "MindMirror",
    slug: "mindmirror",
    version: "1.0.0",
    orientation: "portrait",
    icon: "./assets/icon.png",
    splash: {
      image: "./assets/splash.png",
      resizeMode: "contain",
      backgroundColor: "#ffffff"
    },
    android: {
      package: "com.yourname.mindmirror",
      permissions: ["RECORD_AUDIO"]
    },
    ios: {
      bundleIdentifier: "com.yourname.mindmirror",
      infoPlist: {
        NSSpeechRecognitionUsageDescription: "This app requires speech recognition for voice input.",
        NSMicrophoneUsageDescription: "This app requires microphone access to record your voice."
      }
    },
    extra: {
      serverUrl: process.env.SERVER_URL || "http://localhost:3000"
    }
  }
};
