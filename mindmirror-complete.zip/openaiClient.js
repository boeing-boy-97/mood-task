import Constants from 'expo-constants';

const SERVER = Constants.expoConfig?.extra?.serverUrl || 'http://localhost:3000';

export async function askOpenAI(prompt) {
  try {
    const res = await fetch(`${SERVER.replace(/\/$/, '')}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const data = await res.json();
    return data.reply || 'Sorry, no reply from server.';
  } catch (err) {
    console.error('Proxy request failed', err);
    return 'Sorry, I could not reach the server.';
  }
}
