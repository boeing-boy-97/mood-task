import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const OPENAI_KEY = process.env.OPENAI_API_KEY;

if (!OPENAI_KEY) {
  console.warn('WARNING: OPENAI_API_KEY is not set. Server will run but OpenAI calls will fail.');
}

const client = new OpenAI({ apiKey: OPENAI_KEY });

app.post('/api/chat', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'prompt required' });

    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 800,
    });

    const reply = completion?.choices?.[0]?.message?.content || 'Sorry, no response from OpenAI.';
    res.json({ reply });
  } catch (err) {
    console.error('OpenAI error', err);
    res.status(500).json({ error: 'OpenAI error' });
  }
});

app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
